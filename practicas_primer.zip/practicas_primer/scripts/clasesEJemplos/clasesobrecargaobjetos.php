<?php

    class ClaseSobrecargadaPorDefecto
    {
        
    }