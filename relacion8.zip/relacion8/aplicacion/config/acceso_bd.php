<?php

$servidor = "localhost";
$usuario= "usu9";
$contraseña = "1234";
$baseDatos = "practica9";

//servidor web 
// $servidor = "localhost";
// $usuario= "2daw06";
// $contraseña = "12345678";
// $baseDatos = "BD2DAW06";