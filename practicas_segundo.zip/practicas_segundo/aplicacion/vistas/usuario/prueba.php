<?php

    /**Podemos crear diferentes etiquetas/botones/textos */
    echo CHTML::boton("pulsa este boton",["id"=>"bot_nuevo"]);

    echo CHTML::dibujaEtiqueta("textarea",["rows"=>5,"cols"=>50], "esto va en el textArea");

    

    echo"esto es una vista creada";

