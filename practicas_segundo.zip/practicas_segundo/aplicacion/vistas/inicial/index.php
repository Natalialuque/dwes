<?php
    echo "<br/>";

    echo "Hola mundo.";
    echo "<br/>";
    echo "<br/>".PHP_EOL;

    echo "funciona que no es poco".PHP_EOL;
    



    // echo Sistema::app()->generaURL(["usuario","borrar"]);
    //     echo "<br>";
    // echo CHTML::link("modificar usuario",
    //                     Sistema::app()->generaURL(["usuario","modificar"],["id"=>234]));

    // echo"<br>";
    // echo "elo numero vale $n y la cadena $c";

    // echo CHTML::link("index ejercicio 1",["ejer1","index"])."<br>";
    // echo CHTML::link("insituto","https://www.iespedroespinosa.es")."<br>";
    // echo CHTML ::link("index ejercicio 1:",
    //                     Sistema::app()->generaURL(["ejer1","index"],["id"=>12]),
    //                     ["id"=>"enlace"])."<br>";