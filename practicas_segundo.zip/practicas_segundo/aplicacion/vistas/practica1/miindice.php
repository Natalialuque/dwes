<?php
    echo CHTML::dibujaEtiqueta("p",[],"Practica 1",true);