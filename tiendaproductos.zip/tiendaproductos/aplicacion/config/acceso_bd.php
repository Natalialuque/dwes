<?php

$servidor = "localhost";
$usuario= "usu9";
$contraseña = "1234";
$baseDatos = "tiendaproductos";

//servidor web 
//$servidor = "localhost";
//$usuario= "2daw06";
//$contraseña = "2daw";
//$baseDatos = "BD2DAW06";